package cl.inacap.reciclag;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class ConductorSignUp2 extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_conductor_sign_up2);
    }
}
